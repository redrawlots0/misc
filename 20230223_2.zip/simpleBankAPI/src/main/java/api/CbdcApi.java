package api;

import java.util.List;

import com.fasterxml.jackson.databind.ObjectMapper;

import bean.Cbdc;
import bean.Transaction;
import bean.User;
import dao.CbdcDAO;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("{id}/cbdc")
public class CbdcApi {

	final ObjectMapper mapper = new ObjectMapper();

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Cbdc> getCbdcs(@PathParam("id") String id) throws Exception {
		return CbdcDAO.getCbdc(id);
	}

	@GET
	@Path("destinations")
	@Produces(MediaType.APPLICATION_JSON)
	public List<User> getDestinations(@PathParam("id") String id) throws Exception {
		return CbdcDAO.getDestinations(id);
	}

	@GET
	@Path("transaction")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Transaction> getTransactions(@PathParam("id") String id) throws Exception {
		return CbdcDAO.getTransactions(id);
	}

	@POST
	@Path("transaction")
	@Produces(MediaType.APPLICATION_JSON)
	// @Consumes(MediaType.APPLICATION_JSON)
	public Response putTransactions(@PathParam("id") String id, @QueryParam("date") String date,
			@QueryParam("summary") String summary, @QueryParam("send") int send, @QueryParam("receive") int receive,
			@QueryParam("balance") int balance) throws Exception {
		return CbdcDAO.putTransaction(id, date, summary, send, receive, balance);
	}

	@POST
	@Path("transfer")
	@Produces(MediaType.APPLICATION_JSON)
	// @Consumes(MediaType.APPLICATION_JSON)
	public Response transfer(@PathParam("id") String id, @QueryParam("destination") String destination,
			@QueryParam("amount") int amount) throws Exception {
		return CbdcDAO.transfer(id, destination, amount);
	}

	@POST
	@Path("convert")
	@Produces(MediaType.APPLICATION_JSON)
	// @Consumes(MediaType.APPLICATION_JSON)
	public Response convert(@PathParam("id") String id, @QueryParam("amount") int amount) throws Exception {
		return CbdcDAO.convert(id, amount);
	}
}