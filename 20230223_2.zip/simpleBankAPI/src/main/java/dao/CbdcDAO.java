package dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.codec.digest.DigestUtils;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import bean.Cbdc;
import bean.Transaction;
import bean.User;
import jakarta.ws.rs.core.Response;

public class CbdcDAO {

	static ObjectMapper mapper = new ObjectMapper();
	static Connection conn;

	public static List<Cbdc> getCbdc(String inputId) throws Exception {
		Class.forName(DBConstants.DRIVER_NAME);
		Connection conn = DriverManager.getConnection(DBConstants.JDBC_URL_BANK_DB, DBConstants.USER_ID,
				DBConstants.PASSWORD);
		String sql = "select * from cbdc where id= ?";
		PreparedStatement preparedStatement = conn.prepareStatement(sql);
		preparedStatement.setString(1, inputId);
		ResultSet rs = preparedStatement.executeQuery();
		List<Cbdc> cbdcs = new ArrayList<>();
		while (rs.next()) {
			String hash = rs.getString("hash");
			int amount = Integer.parseInt(rs.getString("amount"));
			String id = rs.getString("id");
			String progmoney = rs.getString("progmoney");
			cbdcs.add(new Cbdc(hash, amount, id, progmoney));
		}
		conn.close();
		return cbdcs;
	}

	public static List<User> getDestinations(String id) throws ClassNotFoundException, SQLException {
		Class.forName(DBConstants.DRIVER_NAME);
		Connection conn = DriverManager.getConnection(DBConstants.JDBC_URL_BANK_DB, DBConstants.USER_ID,
				DBConstants.PASSWORD);
		String sql = "select * from cif";
		PreparedStatement preparedStatement = conn.prepareStatement(sql);
		ResultSet rs = preparedStatement.executeQuery();
		List<User> users = new ArrayList<>();
		while (rs.next()) {
			String tmpId = rs.getString("id");
			String tmpName = rs.getString("name");
			String tmpPassword = rs.getString("password");
			if (!tmpId.equals(id)) {
				users.add(new User(tmpId, tmpName, tmpPassword));
			}
		}
		conn.close();
		return users;
	}

	public static Response putTransaction(String id, String date, String summary, int send, int receive, int balance)
			throws ClassNotFoundException, SQLException {
		Class.forName(DBConstants.DRIVER_NAME);
		Connection conn = DriverManager.getConnection(DBConstants.JDBC_URL_BANK_DB, DBConstants.USER_ID,
				DBConstants.PASSWORD);
		String sql = "insert into transaction values(?,?,?,?,?,?,?)";
		PreparedStatement preparedStatement = conn.prepareStatement(sql);
		preparedStatement.setString(1, DigestUtils.sha256Hex(new Date().toString()));
		preparedStatement.setString(2, id);
		preparedStatement.setString(3, format(date));
		preparedStatement.setString(4, summary);
		preparedStatement.setInt(5, send);
		preparedStatement.setInt(6, receive);
		preparedStatement.setInt(7, balance);
		preparedStatement.executeUpdate();
		conn.close();
		return Response.ok().build();
	}

	private static String format(String date) {
		String year = date.substring(0, 4);
		String month = date.substring(4, 6);
		String day = date.substring(6, 8);
		String hour = date.substring(8, 10);
		String minute = date.substring(10, 12);
		String second = date.substring(12, 14);
		return year + "/" + month + "/" + day + " " + hour + ":" + minute + ":" + second;
	}

	public static List<Transaction> getTransactions(String id) throws ClassNotFoundException, SQLException {
		Class.forName(DBConstants.DRIVER_NAME);
		Connection conn = DriverManager.getConnection(DBConstants.JDBC_URL_BANK_DB, DBConstants.USER_ID,
				DBConstants.PASSWORD);
		String sql = "select * from transaction";
		PreparedStatement preparedStatement = conn.prepareStatement(sql);
		ResultSet rs = preparedStatement.executeQuery();
		List<Transaction> transactions = new ArrayList<>();
		while (rs.next()) {
			String tmpId = rs.getString("id");
			if (tmpId.equals(id)) {
				String tmpHash = rs.getString("hash");
				String tmpDate = rs.getString("date");
				String tmpSummary = rs.getString("summary");
				int tmpSend = Integer.parseInt(rs.getString("send"));
				int tmpReceive = Integer.parseInt(rs.getString("receive"));
				int tmpBalance = Integer.parseInt(rs.getString("balance"));
				transactions.add(new Transaction(tmpHash, tmpId, tmpDate, tmpSummary, tmpSend, tmpReceive, tmpBalance));
			}
		}
		conn.close();
		return transactions;
	}

	public static Response transfer(String inputId, String destination, int amount) throws ClassNotFoundException,
			SQLException, JsonParseException, JsonMappingException, IOException, ParseException {
		Class.forName(DBConstants.DRIVER_NAME);
		conn = DriverManager.getConnection(DBConstants.JDBC_URL_BANK_DB, DBConstants.USER_ID, DBConstants.PASSWORD);

		if (hasEnoughAmount(inputId, amount)) {
			String sql = "select * from cbdc;";
			PreparedStatement preparedStatement = conn.prepareStatement(sql);
			ResultSet rs = preparedStatement.executeQuery();
			int remainAmount = amount;
			while (rs.next()) {
				String tmpHash = rs.getString("hash");
				int tmpAmount = Integer.parseInt(rs.getString("amount"));
				String tmpId = rs.getString("id");
				String tmpProgmoney = rs.getString("progmoney");
				if (inputId.equals(tmpId)) {
					if (remainAmount < tmpAmount) {
						// 分割、移転
						split(tmpHash, tmpId, remainAmount, tmpAmount - remainAmount, tmpProgmoney);
						changeOwner(tmpHash, destination);
						break;
					} else {
						remainAmount -= tmpAmount;
						// 移転
						changeOwner(tmpHash, destination);
					}
				}
				if (remainAmount <= 0) {
					break;
				}
			}
		} else {
			// TODO
		}
		conn.close();

		putTransactionLogs(inputId, destination, amount);

		return Response.ok().build();
	}

	private static void putTransactionLogs(String id, String destination, int amount)
			throws ClassNotFoundException, SQLException {
		String date = DateTimeFormatter.ofPattern("yyyyMMddHHmmss").format(LocalDateTime.now());
		putTransaction(id, date, getName(destination) + "への送金", amount, 0, getAmount(id));
		putTransaction(destination, date, getName(id) + "からの送金", 0, amount, getAmount(destination));
	}

	private static int getAmount(String id) throws SQLException, ClassNotFoundException {
		Class.forName(DBConstants.DRIVER_NAME);
		conn = DriverManager.getConnection(DBConstants.JDBC_URL_BANK_DB, DBConstants.USER_ID, DBConstants.PASSWORD);
		String sql = "select * from cbdc where id= ?";
		PreparedStatement preparedStatement = conn.prepareStatement(sql);
		preparedStatement.setString(1, id);
		ResultSet rs = preparedStatement.executeQuery();
		int amount = 0;
		while (rs.next()) {
			amount += rs.getInt("amount");
		}
		conn.close();
		return amount;
	}

	private static String getName(String id) throws ClassNotFoundException, SQLException {
		Class.forName(DBConstants.DRIVER_NAME);
		conn = DriverManager.getConnection(DBConstants.JDBC_URL_BANK_DB, DBConstants.USER_ID, DBConstants.PASSWORD);
		String sql = "select * from cif where id= ?";
		PreparedStatement preparedStatement = conn.prepareStatement(sql);
		preparedStatement.setString(1, id);
		ResultSet rs = preparedStatement.executeQuery();
		String name = null;
		while (rs.next()) {
			name = rs.getString("name");
		}
		conn.close();
		return name;
	}

	private static void split(String tmpHash, String tmpId, int oldAmount, int newAmount, String tmpProgmoney)
			throws ClassNotFoundException, SQLException {
		Class.forName(DBConstants.DRIVER_NAME);
		conn = DriverManager.getConnection(DBConstants.JDBC_URL_BANK_DB, DBConstants.USER_ID, DBConstants.PASSWORD);
		// String sql = "select * from cbdc where hash= ?";
		String sql = "update cbdc set amount=? where hash=?";
		PreparedStatement preparedStatement = conn.prepareStatement(sql);
		preparedStatement.setInt(1, oldAmount);
		preparedStatement.setString(2, tmpHash);
		preparedStatement.executeUpdate();

		sql = "insert into cbdc values(?,?,?,?)";
		preparedStatement = conn.prepareStatement(sql);
		preparedStatement.setString(1, DigestUtils.sha256Hex(new Date().toString()));
		preparedStatement.setInt(2, newAmount);
		preparedStatement.setString(3, tmpId);
		preparedStatement.setString(4, tmpProgmoney);
		preparedStatement.executeUpdate();

		conn.close();
	}

	private static void changeOwner(String tmpHash, String destination) throws ClassNotFoundException, SQLException {
		Class.forName(DBConstants.DRIVER_NAME);
		conn = DriverManager.getConnection(DBConstants.JDBC_URL_BANK_DB, DBConstants.USER_ID, DBConstants.PASSWORD);
		// String sql = "select * from cbdc where hash= ?";
		String sql = "update cbdc set id=? where hash=?";
		PreparedStatement preparedStatement = conn.prepareStatement(sql);
		preparedStatement.setString(1, destination);
		preparedStatement.setString(2, tmpHash);
		preparedStatement.executeUpdate();
		conn.close();
	}

	private static boolean hasEnoughAmount(String inputId, int amount) {
		return true;
	}

	public static Response convert(String id, int amount) throws ClassNotFoundException, SQLException {
		Class.forName(DBConstants.DRIVER_NAME);
		conn = DriverManager.getConnection(DBConstants.JDBC_URL_BANK_DB, DBConstants.USER_ID, DBConstants.PASSWORD);
		if (hasEnoughAmount(id, amount)) {
			String sql = "select * from cbdc;";
			PreparedStatement preparedStatement = conn.prepareStatement(sql);
			ResultSet rs = preparedStatement.executeQuery();
			int remainAmount = amount;
			while (rs.next()) {
				String tmpHash = rs.getString("hash");
				int tmpAmount = Integer.parseInt(rs.getString("amount"));
				String tmpId = rs.getString("id");
				String tmpProgmoney = rs.getString("progmoney");
				if (id.equals(tmpId) && tmpProgmoney.isEmpty()) {
					if (remainAmount < tmpAmount) {
						// 分割、移転
						split(tmpHash, tmpId, remainAmount, tmpAmount - remainAmount, tmpProgmoney);
						changeOwner(tmpHash, "-");
						break;
					} else {
						remainAmount -= tmpAmount;
						// 移転
						changeOwner(tmpHash, "-");
					}
				}
				if (remainAmount <= 0) {
					break;
				}
			}
			
			sql = "select * from deposit where id=?";
			conn = DriverManager.getConnection(DBConstants.JDBC_URL_BANK_DB, DBConstants.USER_ID, DBConstants.PASSWORD);
			preparedStatement = conn.prepareStatement(sql);
			preparedStatement.setString(1, id);
			rs = preparedStatement.executeQuery();
			int currentAmount = 0;
			while (rs.next()) {
				currentAmount = Integer.parseInt(rs.getString("amount"));
			}
			
			sql = "update deposit set amount=? where id=?";
			preparedStatement = conn.prepareStatement(sql);
			preparedStatement.setInt(1, currentAmount + amount);
			preparedStatement.setString(2, id);
			preparedStatement.executeUpdate();
			
			String date = DateTimeFormatter.ofPattern("yyyyMMddHHmmss").format(LocalDateTime.now());
			putTransaction(id, date, "銀行預金に変換", 0, amount, getAmount(id));
			
		} else {
			// TODO
		}
		conn.close();
		return null;
	}
}
