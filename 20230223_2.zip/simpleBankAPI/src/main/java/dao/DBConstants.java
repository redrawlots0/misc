package dao;

public class DBConstants {
	public final static String DRIVER_NAME = "com.mysql.cj.jdbc.Driver";
	// private final static String JDBC_URL_CIF =
	// "jdbc:mysql://customerinformationfile.copyft4vag23.ap-northeast-1.rds.amazonaws.com/customerinformationfileDB?user=admin&password=password&enabledTLSProtocols=TLSv1.2&useSSL=true&requireSSL=true&verifyServerCertificate=false";
	public final static String JDBC_URL_BANK_DB = "jdbc:mysql://localhost/bank_db";
	public final static String USER_ID = "root";
	public final static String PASSWORD = "zaq12wsx";
}
