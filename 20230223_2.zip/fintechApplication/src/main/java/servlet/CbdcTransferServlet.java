package servlet;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse;
import java.util.Arrays;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.databind.ObjectMapper;

import bean.Cbdc;
import bean.Deposit;
import bean.User;

@WebServlet("/CbdcTransferServlet")
public class CbdcTransferServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	final ObjectMapper mapper = new ObjectMapper();

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {

		request.setCharacterEncoding("UTF-8");

		String destination = request.getParameter("destination");
		int amount = Integer.valueOf(request.getParameter("amount"));
		User user = (User) request.getSession().getAttribute("user");
		try {
			transferCbdc(user.getId(), destination, amount);
			HttpSession session = request.getSession();
			session.setAttribute("cbdc", getCbdcAmount(user.getId()));
			session.setAttribute("deposit", getDepositAmount(user.getId()));
			RequestDispatcher dispatcher = request.getRequestDispatcher("WEB-INF/jsp/main.jsp");
			dispatcher.forward(request, response);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	private int getDepositAmount(String id) throws IOException, InterruptedException {
		String url = "http://localhost:8080/simpleBankAPI/" + id + "/deposit";
		HttpClient client = HttpClient.newHttpClient();
		HttpRequest req = HttpRequest.newBuilder().uri(URI.create(url)).build();
		HttpResponse<String> res = client.send(req, HttpResponse.BodyHandlers.ofString());
		Deposit deposit = mapper.readValue(res.body(), Deposit.class);
		return deposit.getAmount();
	}

	private int getCbdcAmount(String id) throws IOException, InterruptedException {
		String url = "http://localhost:8080/simpleBankAPI/" + id + "/cbdc";
		HttpClient client = HttpClient.newHttpClient();
		HttpRequest req = HttpRequest.newBuilder().uri(URI.create(url)).build();
		HttpResponse<String> res = client.send(req, HttpResponse.BodyHandlers.ofString());
		List<Cbdc> cbdcs = Arrays.asList(mapper.readValue(res.body(), Cbdc[].class));
		int amount = 0;
		for (Cbdc cbdc : cbdcs) {
			amount += cbdc.getAmount();
		}
		return amount;
	}

	private void transferCbdc(String id, String destination, int amount) throws IOException, InterruptedException {
		String url = "http://localhost:8080/simpleBankAPI/" + id + "/cbdc/transfer?destination=" + destination
				+ "&amount=" + amount;
		HttpClient client = HttpClient.newHttpClient();
		HttpRequest postRequest = HttpRequest.newBuilder().uri(URI.create(url)).POST(BodyPublishers.ofString(""))
				.setHeader("Content-Type", "application/json").build();
		HttpResponse<String> res = client.send(postRequest, HttpResponse.BodyHandlers.ofString());

	}

}
