package servlet;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Arrays;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import bean.Cbdc;
import bean.Deposit;
import bean.User;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	final ObjectMapper mapper = new ObjectMapper();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {

		request.setCharacterEncoding("UTF-8");

		String id = request.getParameter("id");
		String password = request.getParameter("password");
		User user;
		try {
			user = getUser(id, password);
			if (isValidUser(user)) {
				HttpSession session = request.getSession();
				session.setAttribute("user", user);
				session.setAttribute("cbdc", getCbdcAmount(user.getId()));
				session.setAttribute("deposit", getDepositAmount(user.getId()));
				session.setAttribute("destinations", getDestinations(user.getId()));
				RequestDispatcher dispatcher = request.getRequestDispatcher("WEB-INF/jsp/main.jsp");
				dispatcher.forward(request, response);
			} else {
				// TODO
			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ServletException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	private List<User> getDestinations(String id) throws IOException, InterruptedException {
		String url = "http://localhost:8080/simpleBankAPI/" + id + "/cbdc/destinations";
		HttpClient client = HttpClient.newHttpClient();
		HttpRequest req = HttpRequest.newBuilder().uri(URI.create(url)).build();
		HttpResponse<String> res = client.send(req, HttpResponse.BodyHandlers.ofString());	
		List<User> destinations = mapper.readValue(res.body(), new TypeReference<List<User>>() {
		});
		return destinations;
	}

	private int getDepositAmount(String id) throws IOException, InterruptedException {
		String url = "http://localhost:8080/simpleBankAPI/" + id + "/deposit";
		HttpClient client = HttpClient.newHttpClient();
		HttpRequest req = HttpRequest.newBuilder().uri(URI.create(url)).build();
		HttpResponse<String> res = client.send(req, HttpResponse.BodyHandlers.ofString());
		Deposit deposit = mapper.readValue(res.body(), Deposit.class);
		return deposit.getAmount();
	}

	private int getCbdcAmount(String id) throws IOException, InterruptedException {
		String url = "http://localhost:8080/simpleBankAPI/" + id + "/cbdc";
		HttpClient client = HttpClient.newHttpClient();
		HttpRequest req = HttpRequest.newBuilder().uri(URI.create(url)).build();
		HttpResponse<String> res = client.send(req, HttpResponse.BodyHandlers.ofString());
		List<Cbdc> cbdcs = Arrays.asList(mapper.readValue(res.body(), Cbdc[].class));
		int amount = 0;
		for (Cbdc cbdc : cbdcs) {
			amount += cbdc.getAmount();
		}
		return amount;
	}

	private boolean isValidUser(User user) {
		if (user == null) {
			return false;
		} else {
			return true;
		}
	}

	private User getUser(String id, String password) throws IOException, InterruptedException {
		String url = "http://localhost:8080/simpleBankAPI/login?id=" + id + "&password=" + password;
		HttpClient client = HttpClient.newHttpClient();
		HttpRequest req = HttpRequest.newBuilder().uri(URI.create(url)).build();
		HttpResponse<String> res = client.send(req, HttpResponse.BodyHandlers.ofString());
		User user = mapper.readValue(res.body(), User.class);
		return user;
	}

}
