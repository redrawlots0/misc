package servlet;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Arrays;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.databind.ObjectMapper;

import bean.Transaction;
import bean.User;

@WebServlet("/CbdcTransactionServlet")
public class CbdcTransactionServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	final ObjectMapper mapper = new ObjectMapper();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {

		request.setCharacterEncoding("UTF-8");

		User user = (User) request.getSession().getAttribute("user");
		try {
			HttpSession session = request.getSession();
			session.setAttribute("transaction", getCbdcTransaction(user.getId()));
			RequestDispatcher dispatcher = request.getRequestDispatcher("WEB-INF/jsp/transaction.jsp");
			dispatcher.forward(request, response);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	private List<Transaction> getCbdcTransaction(String id) throws IOException, InterruptedException {
		String url = "http://localhost:8080/simpleBankAPI/" + id + "/cbdc/transaction";
		HttpClient client = HttpClient.newHttpClient();
		HttpRequest req = HttpRequest.newBuilder().uri(URI.create(url)).build();
		HttpResponse<String> res = client.send(req, HttpResponse.BodyHandlers.ofString());
		List<Transaction> transactions = Arrays.asList(mapper.readValue(res.body(), Transaction[].class));
		return transactions;
	}

}
