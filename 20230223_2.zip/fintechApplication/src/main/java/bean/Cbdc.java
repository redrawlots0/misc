package bean;

import java.util.Date;

import org.apache.commons.codec.digest.DigestUtils;

public class Cbdc {

	String hash;
	int amount;
	String id;
	String progmoney;

	public Cbdc() {
	}

	public Cbdc(String hash, int amount, String id, String progmoney) {
		this.hash = calcHash(amount, id, progmoney);
		this.amount = amount;
		this.id = id;
		this.progmoney = progmoney;
	}

	private String calcHash(int amount, String id, String progmoney) {
		return DigestUtils.sha256Hex(new Date().toString());
	}

	public String getHash() {
		return hash;
	}

	public int getAmount() {
		return amount;
	}

	public String getId() {
		return id;
	}

	public String getProgmoney() {
		return progmoney;
	}

}
