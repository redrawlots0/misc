delete from cbdc;
insert into cbdc values('d804b81e5ffb0d5817622a1adad36b3eec140b4c0ff55319c3b159904c3ec74c',10000,'taro','');
insert into cbdc values('608b17c5ab27c7a11de31bbe53ef94d17fd7e10c57ddad9e541697799e7b7af5',5000,'taro','');
insert into cbdc values('11f8024cc893324bdf9e9d3ce20cf585e2f3800514b6264b379154bc5c1ecd19',5000,'jiro','');
insert into cbdc values('9f3918530d30df17051eeb121706f9c158d5f8ce418ff04a489ff7127c80bdbd',1000,'jiro','');
insert into cbdc values('192cd2f7410d5ea777e91ff72b4f9521f50863321c065f4eb71f1e51064f8f05',5000,'taro','');

delete from deposit;
insert into deposit values('taro',10000);
insert into deposit values('jiro',20000);

delete from transaction;
insert into transaction values('1fa96c69faec7d2c599da2b86cf5ec59bf2c05046058ac1a62a409582dfa0a42','taro','2023/01/01 12:34:56','日銀次郎への送金',5000,0,10000);
insert into transaction values('138e50bf1d647ad1f53b302c7e6423453f49b8f6a8d3e111175339f0c42211bd','taro','2023/01/02 11:11:11','日銀次郎への送金',10000,0,10000);
insert into transaction values('afb955fb6b345152f29253ad797062e3e9d1fcd994018d3a59e5431434758ee8','jiro','2023/02/01 00:00:00','日銀太郎への送金',10000,0,10000);
insert into transaction values('7dada9386d7753bfaff7c0087ba7f30c3addfdb0a81f29a6660a7c3611fcbc16','jiro','2023/02/01 23:59:59','日銀太郎への送金',10000,0,10000);

delete from cif;
insert into cif values('taro','日銀太郎','taro');
insert into cif values('jiro','日銀次郎','jiro');
insert into cif values('saburo','日銀三郎','saburo');
insert into cif values('store','日銀ストア','store');