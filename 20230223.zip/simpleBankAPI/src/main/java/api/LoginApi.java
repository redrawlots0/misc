package api;

import bean.User;
import dao.UserDAO;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path("login")
public class LoginApi {

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public User login(@QueryParam("id") String id, @QueryParam("password") String password) throws Exception {
		return UserDAO.findUser(id, password);
	}

}
