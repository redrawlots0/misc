package servlet;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@SuppressWarnings("serial")
@WebServlet("/ProgramabilityTransitionServlet")
public class ProgramabilityTransitionServlet extends BaseServlet {

	static Map<String, String> labelMap = createLabelMap();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {

		request.setCharacterEncoding("UTF-8");

		Map<String, Map<String, String>> programabilities = getProgramabilities();
		try {
			HttpSession session = request.getSession();
			session.setAttribute("programabilities", programabilities);
			RequestDispatcher dispatcher = request.getRequestDispatcher("WEB-INF/jsp/programability.jsp");
			dispatcher.forward(request, response);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static Map<String, String> createLabelMap() {
		Map<String, String> labelMap = new HashMap<>();
		return labelMap;
	}

	private Map<String, Map<String, String>> getProgramabilities() throws IOException {
		Map<String, Map<String, String>> programabilities = new LinkedHashMap<>();
//		Path programabilityConfigPath = Paths.get("git", "fintechApplication", "fintechApplication", "external",
//				"programability.config");
		//System.out.println(System.getProperty("user.dir"));
		Path programabilityConfigPath = Paths.get("C:","pleiades","pleiades","workspace", "fintechApplication", "external",
				"programability.config");
		
		List<String> lines = Files.readAllLines(programabilityConfigPath, StandardCharsets.UTF_8);
		for (String line : lines) {
			List<String> configs = Arrays.asList(line.split(","));
			Map<String, String> configMap = new LinkedHashMap<>();
			String hash = null;
			for (String config : configs) {
				String[] items = config.split("=");
				if ("hash".equals(items[0])) {
					hash = items[1];
				} else if ("enable".equals(items[0])) {
					if (items.length == 1) {
						configMap.put("checked", "");
					} else {
						configMap.put("checked", "checked");
					}
				} else {
					configMap.put(items[0], items[1]);
				}
			}
			programabilities.put(hash, configMap);
		}
		return programabilities;
	}

}
