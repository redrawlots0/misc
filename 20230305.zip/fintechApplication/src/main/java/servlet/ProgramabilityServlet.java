package servlet;

import java.io.IOException;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@SuppressWarnings("serial")
@WebServlet("/ProgramabilityServlet")
public class ProgramabilityServlet extends BaseServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {

		request.setCharacterEncoding("UTF-8");

		@SuppressWarnings("unchecked")
		Map<String, Map<String, String>> programabilities = (Map<String, Map<String, String>>) request.getSession()
				.getAttribute("programabilities");
		Map<String, String> programability = programabilities.get(request.getParameter("hash"));
		HttpSession session = request.getSession();
		session.setAttribute("programability", programability);
		
//		
//		int amount = -1, conditionAmount = -1;
//		String conditionOperand = null, conditionType = null, method = null, event = null, timing = null, name = null,
//				destination = null, type = null, hash = null;
//		for (Map.Entry<String, String> entry : programability.entrySet()) {
//			if ("amount".equals(entry.getKey())) {
//				amount = Integer.getInteger(entry.getValue());
//			} else if ("condition".equals(entry.getKey())) {
//				String[] conditions = entry.getValue().split(":\\(\\)");
//				conditionOperand = conditions[0];
//				conditionType = conditions[1];
//				conditionAmount = Integer.getInteger(conditions[2]);
//			} else if ("method".equals(entry.getKey())) {
//				method = entry.getValue();
//			} else if ("timing".equals(entry.getKey())) {
//				timing = entry.getValue();
//			} else if ("name".equals(entry.getKey())) {
//				name = entry.getValue();
//			} else if ("destination".equals(entry.getKey())) {
//				destination = entry.getValue();
//			} else if ("event".equals(entry.getKey())) {
//				event = entry.getValue();
//			} else if ("type".equals(entry.getKey())) {
//				type = entry.getValue();
//			} else if ("hash".equals(entry.getKey())) {
//				hash = entry.getValue();
//			} else {
//				System.err.println("@@");
//			}
//		}
//		HttpSession session = request.getSession();
//		session.setAttribute("hash", hash);
//		session.setAttribute("name", name);
//		session.setAttribute("method", method);
//		session.setAttribute("event", event);
//		session.setAttribute("timing", timing);
//		session.setAttribute("type", type);
//		session.setAttribute("destination", destination);
//		session.setAttribute("amount", amount);
//		session.setAttribute("conditionType", conditionType);
//		session.setAttribute("conditionOperand", conditionOperand);
//		session.setAttribute("conditionAmount", conditionAmount);
		RequestDispatcher dispatcher = request.getRequestDispatcher("WEB-INF/jsp/programability-detail.jsp");
		dispatcher.forward(request, response);
	}

}
