package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.User;

@SuppressWarnings("serial")
@WebServlet("/CbdcConvertServlet")
public class CbdcConvertServlet extends BaseServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {

		request.setCharacterEncoding("UTF-8");

		int amount = Integer.valueOf(request.getParameter("amount"));
		User user = (User) request.getSession().getAttribute("user");
		try {
			convertCbdc(user.getId(), amount);
			HttpSession session = request.getSession();
			session.setAttribute("cbdc", format(getCbdcAmount(user.getId())));
			session.setAttribute("deposit", format(getDepositAmount(user.getId())));
			RequestDispatcher dispatcher = request.getRequestDispatcher("WEB-INF/jsp/main.jsp");
			dispatcher.forward(request, response);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
