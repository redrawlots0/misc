package bean;

public class Deposit {

	String id;
	int amount;
	
	public Deposit() {
	}

	public Deposit(String id, int amount) {
		this.id = id;
		this.amount = amount;
	}

	public String getId() {
		return id;
	}

	public int getAmount() {
		return amount;
	}

}
