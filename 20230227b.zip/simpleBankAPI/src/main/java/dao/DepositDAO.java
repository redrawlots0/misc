package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.apache.commons.codec.digest.DigestUtils;

import bean.Deposit;
import jakarta.ws.rs.core.Response;

public class DepositDAO {

	public static Deposit getDeposit(String inputId) throws ClassNotFoundException, SQLException {
		Class.forName(DBConstants.DRIVER_NAME);
		Connection conn = DriverManager.getConnection(DBConstants.JDBC_URL_BANK_DB, DBConstants.USER_ID,
				DBConstants.PASSWORD);
		String sql = "select * from deposit where id= ?";
		PreparedStatement preparedStatement = conn.prepareStatement(sql);
		preparedStatement.setString(1, inputId);
		ResultSet rs = preparedStatement.executeQuery();
		int amount = -1;
		while (rs.next()) {
			amount = rs.getInt("amount");
		}
		conn.close();
		return new Deposit(inputId, amount);
	}

	public static Response convert(String id, int amount) throws ClassNotFoundException, SQLException {
		Class.forName(DBConstants.DRIVER_NAME);
		Connection conn = DriverManager.getConnection(DBConstants.JDBC_URL_BANK_DB, DBConstants.USER_ID,
				DBConstants.PASSWORD);
		String sql = "select * from deposit where id= ?";
		PreparedStatement preparedStatement = conn.prepareStatement(sql);
		preparedStatement.setString(1, id);
		ResultSet rs = preparedStatement.executeQuery();
		int currentAmount = -1;
		while (rs.next()) {
			currentAmount = rs.getInt("amount");
		}

		sql = "update deposit set amount=? where id=?";
		preparedStatement = conn.prepareStatement(sql);
		preparedStatement.setInt(1, currentAmount - amount);
		preparedStatement.setString(2, id);
		preparedStatement.executeUpdate();

		sql = "insert into cbdc values(?,?,?,?)";
		preparedStatement = conn.prepareStatement(sql);
		preparedStatement.setString(1, DigestUtils.sha256Hex(new Date().toString()));
		preparedStatement.setInt(2, amount);
		preparedStatement.setString(3, id);
		preparedStatement.setString(4, "");
		preparedStatement.executeUpdate();

		String date = DateTimeFormatter.ofPattern("yyyyMMddHHmmss").format(LocalDateTime.now());
		putTransaction(id, date, "銀行預金からの変換", amount, 0, getAmount(id));

		conn.close();
		return null;
	}

	public static Response putTransaction(String id, String date, String summary, int send, int receive, int balance)
			throws ClassNotFoundException, SQLException {
		Class.forName(DBConstants.DRIVER_NAME);
		Connection conn = DriverManager.getConnection(DBConstants.JDBC_URL_BANK_DB, DBConstants.USER_ID,
				DBConstants.PASSWORD);
		String sql = "insert into transaction values(?,?,?,?,?,?,?)";
		PreparedStatement preparedStatement = conn.prepareStatement(sql);
		preparedStatement.setString(1, DigestUtils.sha256Hex(new Date().toString()));
		preparedStatement.setString(2, id);
		preparedStatement.setString(3, format(date));
		preparedStatement.setString(4, summary);
		preparedStatement.setInt(5, send);
		preparedStatement.setInt(6, receive);
		preparedStatement.setInt(7, balance);
		preparedStatement.executeUpdate();
		conn.close();
		return Response.ok().build();
	}

	private static String format(String date) {
		String year = date.substring(0, 4);
		String month = date.substring(4, 6);
		String day = date.substring(6, 8);
		String hour = date.substring(8, 10);
		String minute = date.substring(10, 12);
		String second = date.substring(12, 14);
		return year + "/" + month + "/" + day + " " + hour + ":" + minute + ":" + second;
	}

	private static int getAmount(String id) throws SQLException, ClassNotFoundException {
		Class.forName(DBConstants.DRIVER_NAME);
		Connection conn = DriverManager.getConnection(DBConstants.JDBC_URL_BANK_DB, DBConstants.USER_ID,
				DBConstants.PASSWORD);
		String sql = "select * from cbdc where id= ?";
		PreparedStatement preparedStatement = conn.prepareStatement(sql);
		preparedStatement.setString(1, id);
		ResultSet rs = preparedStatement.executeQuery();
		int amount = 0;
		while (rs.next()) {
			amount += rs.getInt("amount");
		}
		conn.close();
		return amount;
	}
}
