package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import bean.User;

public class UserDAO {

	public static User findUser(String inputId, String inputPassword) throws Exception {
		Class.forName(DBConstants.DRIVER_NAME);
		Connection conn = DriverManager.getConnection(DBConstants.JDBC_URL_BANK_DB, DBConstants.USER_ID, DBConstants.PASSWORD);
		String sql = "select * from cif where id= ?";
		PreparedStatement preparedStatement = conn.prepareStatement(sql);
		preparedStatement.setString(1, inputId);
		ResultSet rs = preparedStatement.executeQuery();
		String id = null, name = null, password = null;
		while (rs.next()) {
			id = rs.getString("id");
			name = rs.getString("name");
			password = rs.getString("password");
			if (!inputId.equals(id) || !inputPassword.equals(password)) {
				return null;
			}
		}
		conn.close();
		return new User(id, name, password);
	}
}
