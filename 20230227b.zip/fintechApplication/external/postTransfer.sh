#!/bin/bash

sum=`curl -X GET http://localhost:8080/simpleBankAPI/taro/cbdc/ | jq '[.[].amount]|add'`
if [ $sum -lt 10000 ]; then
  curl -X POST "http://localhost:8080/simpleBankAPI/taro/deposit/convert?amount=10000"
fi
