package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.databind.ObjectMapper;

import bean.User;

@WebServlet("/CbdcTransactionServlet")
public class CbdcTransactionServlet extends BaseServlet {

	private static final long serialVersionUID = 1L;
	final ObjectMapper mapper = new ObjectMapper();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {

		request.setCharacterEncoding("UTF-8");

		User user = (User) request.getSession().getAttribute("user");
		try {
			HttpSession session = request.getSession();
			session.setAttribute("transaction", getCbdcTransaction(user.getId()));
			RequestDispatcher dispatcher = request.getRequestDispatcher("WEB-INF/jsp/transaction.jsp");
			dispatcher.forward(request, response);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
