package servlet;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServlet;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import bean.Cbdc;
import bean.Deposit;
import bean.Transaction;
import bean.User;

public class BaseServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private static final ObjectMapper mapper = new ObjectMapper();

	public String format(int amount) {
		return "￥" + String.format("%,d", amount);
	}

	public int getDepositAmount(String id) throws IOException, InterruptedException {
		String url = "http://localhost:8080/simpleBankAPI/" + id + "/deposit";
		HttpClient client = HttpClient.newHttpClient();
		HttpRequest req = HttpRequest.newBuilder().uri(URI.create(url)).build();
		HttpResponse<String> res = client.send(req, HttpResponse.BodyHandlers.ofString());
		Deposit deposit = mapper.readValue(res.body(), Deposit.class);
		return deposit.getAmount();
	}

	public int getCbdcAmount(String id) throws IOException, InterruptedException {
		String url = "http://localhost:8080/simpleBankAPI/" + id + "/cbdc";
		HttpClient client = HttpClient.newHttpClient();
		HttpRequest req = HttpRequest.newBuilder().uri(URI.create(url)).build();
		HttpResponse<String> res = client.send(req, HttpResponse.BodyHandlers.ofString());
		List<Cbdc> cbdcs = Arrays.asList(mapper.readValue(res.body(), Cbdc[].class));
		int amount = 0;
		for (Cbdc cbdc : cbdcs) {
			amount += cbdc.getAmount();
		}
		return amount;
	}

	public void convertCbdc(String id, int amount) throws IOException, InterruptedException {
		String url = "http://localhost:8080/simpleBankAPI/" + id + "/cbdc/convert?amount=" + amount;
		HttpClient client = HttpClient.newHttpClient();
		HttpRequest postRequest = HttpRequest.newBuilder().uri(URI.create(url)).POST(BodyPublishers.ofString(""))
				.setHeader("Content-Type", "application/json").build();
		HttpResponse<String> res = client.send(postRequest, HttpResponse.BodyHandlers.ofString());
	}

	public List<Transaction> getCbdcTransaction(String id) throws IOException, InterruptedException {
		String url = "http://localhost:8080/simpleBankAPI/" + id + "/cbdc/transaction";
		HttpClient client = HttpClient.newHttpClient();
		HttpRequest req = HttpRequest.newBuilder().uri(URI.create(url)).build();
		HttpResponse<String> res = client.send(req, HttpResponse.BodyHandlers.ofString());
		List<Transaction> transactions = Arrays.asList(mapper.readValue(res.body(), Transaction[].class));
		return transactions;
	}

	public void transferCbdc(String id, String destination, int amount) throws IOException, InterruptedException {
		externalProcess("preTransfer.sh");
		String url = "http://localhost:8080/simpleBankAPI/" + id + "/cbdc/transfer?destination=" + destination
				+ "&amount=" + amount;
		HttpClient client = HttpClient.newHttpClient();
		HttpRequest postRequest = HttpRequest.newBuilder().uri(URI.create(url)).POST(BodyPublishers.ofString(""))
				.setHeader("Content-Type", "application/json").build();
		HttpResponse<String> res = client.send(postRequest, HttpResponse.BodyHandlers.ofString());
		externalProcess("postTransfer.sh");
	}

	public void externalProcess(String script) throws IOException {
		// TODO
		Path scriptPath = Paths.get("git", "fintechApplication", "fintechApplication", "external", script);
		if (Files.exists(scriptPath)) {
			Process process = Runtime.getRuntime().exec(scriptPath.toString());
			// TODO
		}
	}

	public void convertDeposit(String id, int amount) throws IOException, InterruptedException {
		String url = "http://localhost:8080/simpleBankAPI/" + id + "/deposit/convert?amount=" + amount;
		HttpClient client = HttpClient.newHttpClient();
		HttpRequest postRequest = HttpRequest.newBuilder().uri(URI.create(url)).POST(BodyPublishers.ofString(""))
				.setHeader("Content-Type", "application/json").build();
		HttpResponse<String> res = client.send(postRequest, HttpResponse.BodyHandlers.ofString());
	}

	public List<User> getDestinations(String id) throws IOException, InterruptedException {
		String url = "http://localhost:8080/simpleBankAPI/" + id + "/cbdc/destinations";
		HttpClient client = HttpClient.newHttpClient();
		HttpRequest req = HttpRequest.newBuilder().uri(URI.create(url)).build();
		HttpResponse<String> res = client.send(req, HttpResponse.BodyHandlers.ofString());
		List<User> destinations = mapper.readValue(res.body(), new TypeReference<List<User>>() {
		});
		return destinations;
	}

	public User getUser(String id, String password) throws IOException, InterruptedException {
		String url = "http://localhost:8080/simpleBankAPI/login?id=" + id + "&password=" + password;
		HttpClient client = HttpClient.newHttpClient();
		HttpRequest req = HttpRequest.newBuilder().uri(URI.create(url)).build();
		HttpResponse<String> res = client.send(req, HttpResponse.BodyHandlers.ofString());
		User user = mapper.readValue(res.body(), User.class);
		return user;
	}
}
