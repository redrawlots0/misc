package bean;

public class Cbdc {

	String hash;
	int amount;
	String id;
	String progmoney;

	public Cbdc() {
	}

	public Cbdc(String hash, int amount, String id, String progmoney) {
		this.hash = hash;
		this.amount = amount;
		this.id = id;
		this.progmoney = progmoney;
	}

	public String getHash() {
		return hash;
	}

	public int getAmount() {
		return amount;
	}

	public String getId() {
		return id;
	}

	public String getProgmoney() {
		return progmoney;
	}

}
