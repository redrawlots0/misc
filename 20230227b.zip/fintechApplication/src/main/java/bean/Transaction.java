package bean;

public class Transaction {

	String hash;
	String id;
	String date;
	String summary;
	int send;
	int receive;
	int balance;
	
	public Transaction() {
	}
	
	public Transaction(String hash, String id, String date, String summary, int send, int receive, int balance) {
		this.hash = hash;
		this.id = id;
		this.date = date;
		this.summary = summary;
		this.send = send;
		this.receive = receive;
		this.balance = balance;
	}

	public String getHash() {
		return hash;
	}

	public String getId() {
		return id;
	}

	public String getDate() {
		return date;
	}

	public String getSummary() {
		return summary;
	}

	public int getSend() {
		return send;
	}

	public int getReceive() {
		return receive;
	}

	public int getBalance() {
		return balance;
	}

}
